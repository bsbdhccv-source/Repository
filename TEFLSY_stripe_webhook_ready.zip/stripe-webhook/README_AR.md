# شحن نقاط TEFLSY عبر Stripe Webhook (آمن)

هذا الخادم يشحن النقاط **فقط** بعد حدث دفع ناجح من Stripe (`checkout.session.completed`).

## 1) المتطلبات
- حساب Stripe
- مشروع Firebase (Realtime Database)
- استضافة Node.js (Render / Railway / VPS / أي خادم)

## 2) إعداد Firebase
1. Firebase Console → Project Settings → Service accounts  
2. Generate new private key → حمّل JSON  
3. سمّه `serviceAccount.json` وضعه بجانب `server.js`  
4. انسخ رابط القاعدة مثل:  
   `https://YOUR_ID-default-rtdb.firebaseio.com`

## 3) إعداد الملف
```bash
cd stripe-webhook
cp .env.example .env
# عدّل .env
npm install
npm start
```

## 4) متغيرات `.env`
```
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
FIREBASE_DATABASE_URL=https://....firebaseio.com
FIREBASE_SERVICE_ACCOUNT=./serviceAccount.json
PORT=3000
```

## 5) Webhook في Stripe
1. Developers → Webhooks → Add endpoint  
2. الرابط: `https://YOUR_DOMAIN/webhook`  
3. اختر الحدث: `checkout.session.completed`  
4. انسخ **Signing secret** (`whsec_...`) إلى `.env`

## 6) Payment Link
لكل باقة أنشئ Payment Link في Stripe.

في التطبيق يُفتح الرابط بهذا الشكل تلقائياً:
```
https://buy.stripe.com/XXXX?client_reference_id=USERCODE__90
```
حيث `90` = عدد النقاط.

أو أضف في metadata للرابط من لوحة Stripe:
- `points` = 90
- `userCode` يُمرَّر عبر `client_reference_id`

## 7) صفحة النجاح (إصلاح الشاشة البيضاء)
في إعدادات Payment Link:
- After payment → **Don't show confirmation page** أو  
- Success URL: `https://YOUR_DOMAIN/success.html`  
- Cancel URL: `https://YOUR_DOMAIN/cancel.html`

## 8) الأمان
- لا تضع `sk_` داخل تطبيق المستخدم أبداً  
- الشحن يتم فقط من هذا الخادم بعد تحقق توقيع Stripe  
- لن تُشحن نقاط بدون دفع ناجح حقيقي

## 9) قواعد Firebase
اسمح للخادم (Admin SDK يتجاوز القواعد). لا حاجة لتغيير قواعد العميل.
